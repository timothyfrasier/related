#ifndef FAMILY_SIM_H
#define FAMILY_SIM_H

#ifdef __cplusplus
extern "C" {
#endif

#include <R.h>
#include <Rinternals.h>

SEXP family_sim(SEXP);

#ifdef __cplusplus
}
#endif

#endif
